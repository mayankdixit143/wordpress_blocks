<?php

/**
 * Plugin Name: my block    
 * Author: Mayank
 * Version: 1.0.0
 */

function loadMyBlockFiles_admin() {
  wp_enqueue_script(
    'my-super-unique-handle',
    plugin_dir_url(__FILE__) . 'my-block.js',
    array('wp-blocks', 'wp-i18n', 'wp-editor'),
    true
  );
  wp_enqueue_style(
    'gutenberg-notice-block-editor',
    plugins_url( 'block.css', __FILE__ ),
    array()
 );
}
 
add_action('enqueue_block_editor_assets', 'loadMyBlockFiles_admin');

function loadMyBlockFiles_frontend() {
  wp_enqueue_style(
        'gutenberg-notice-block-editor',
        plugins_url( 'block.css', __FILE__ ),
        array()
     );
  }
add_action( 'wp_enqueue_scripts', 'loadMyBlockFiles_frontend' );