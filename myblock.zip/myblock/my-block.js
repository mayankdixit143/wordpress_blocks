var el = wp.element.createElement;
wp.blocks.registerBlockType('mayank/border-box', {
  title: 'notice',
  icon: 'smiley',
  category: 'common',
  attributes: {
    content: {type: 'string'},
    color: {type: 'string'}
  },
  edit: function(props) {
    function updateContent(event) {
      props.setAttributes({content: event.target.value})
    }
    return React.createElement("h3", null, "Mayank");
  },

  save: function(props) {
    return el("div", {
      class: "card-block"
    }, el("h2", null, "container"), el("div", {
      class: "row"
    }, el("div", {
      class: "col-md-4",
      style: "height:",
    }, el("div", {
      class: "education-experience"
    }, el("small", {
      class: "date"
    }, "2017-2015"), el("h3", {
      class: "h5 date-title"
    }, "block 1"), el("p", null, "Chicago University"))), el("div", {
      class: "col-md-4"
    }, el("div", {
      class: "education-experience"
    }, el("small", {
      class: "date"
    }, "2015-2012"), el("h3", {
      class: "h5 date-title"
    }, "block2 "), el("p", null, "Ecole 87"))), el("div", {
      class: "col-md-4"
    }, el("div", {
      class: "education-experience"
    }, el("small", {
      class: "date"
    }, "2012-2011"), el("h3", {
      class: "h5 date-title"
    }, "block3"), el("p", null, "Pascal\u2019s Lee Studio")))));
  }
}
)